//3. Write a program which generates the series 1,4,27,16,125,36

package Assignment3;
class Que3Series
{
public static void main(String[] args) 
{ 
 for(int i=1; i<=6; i++)
    {
      if (i % 2 == 0) 
      {
      System.out.print(i*i + " " ); 
      }
      else
      {
        System.out.print(i*i*i + " " );  
      }
    System.out.print(""); 
  }
 System.out.println(); 
}
}
