/*4.Given an array of integers, print whether the numbers are in ascending order or in descending
order or in random order without sorting
Input: [5,14,35,90,139] Output: Ascending
Input: [88,67,35,14,-12] Output: Descending
Input: [65,14,129,34,7] Output: Random*/
package Assignment3;
import java.util.Scanner;
class Que4ADR
{
    public static void main(String args[])
    {
         Scanner ss = new Scanner(System.in);
        System.out.println("Enter the Length");
        int b = ss.nextInt();
        int s[] = new int[b];
         System.out.println("Enter the Elements");
         System.out.println();
        for(int i =0;i<s.length;i++)
        {
            s[i] = ss.nextInt();
        }
        for(int i:s)
        {
            System.out.println(i);
        }
        System.out.println();
        int a=1,d=1,i;
        i = 0;
            
        while ((a == 1 || d == 1) && i < b - 1) //b=n
        {
          if (s[i] < s[i+1])
            d = 0;
          else if (s[i] > s[i+1])
            a = 0;
          i++;
        }

        if (a == 1)
        System.out.println("The array is sorted in ascending order");
       else if (d == 1)
         System.out.println("The array is sorted in descending order");
       else
         System.out.println("The array is Random");

  
    }
    
}
