/*2.Write a program which takes an array of integers and prints the running average of 3 consecutive
integers. In case the array has fewer than 3 integers, there should be no output.
Input: [5,14,35,89,140]
Output: [18, 46, 88]
(Explanation: 18=(5+14+35/3, 46=(14+35+89)/3, ...)
*/
package Assignment3;
import java.util.Scanner;

class Que2Average
{
    public static void main(String args[])
    {
        Scanner ss = new Scanner(System.in);
        
        
        //Scanner Input Array 1
        System.out.println("Enter Number of Elements in Array");
        int a = ss.nextInt();
        int arr1[] = new int[a];
        
        System.out.println("Enter Elements");
        for(int i =0;i<arr1.length;i++)
        {
            arr1[i] = ss.nextInt();
        }
        System.out.print("Array 1 =");
        for(int i:arr1)
        {
            System.out.print(i + " ");
        }
        System.out.println();
      
       int n =0;
        double k=0;
    
            for(int j =n;j<arr1.length;j++)
                {
                    if((n+3)<=arr1.length)
                    {
                            for(int i =0;i<3;i++)
                            {
                                k = k + arr1[i+j];
                            }
                               
                            System.out.println(k/3);
                                    n++;
                                    k=0;
                    }
                }  
 
    }
}

