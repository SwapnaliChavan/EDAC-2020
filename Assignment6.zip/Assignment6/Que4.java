package Assignment6;
interface college
{
    void name();
}
interface Exam
{
    void result();
}
class Student4 implements college,Exam
{
    String name;
    String result;
    int std;
    Student4(String name)
    {
        this.name = name;
    }
    Student4(String result,int std)
    {
        this.result = result;
        this.std = std;
    }
    public void name()
    {
        System.out.println("Name="+name);
    }
    
    public void result()
    {
        System.out.println("Result="+result);
    }
}
class Que4
{
    public static void main(String args[])
    {
        Student4 s = new Student4("Swap");
        s.name();
        Student4 s1 = new Student4("Pass",4);
        s1.result();
    }
}