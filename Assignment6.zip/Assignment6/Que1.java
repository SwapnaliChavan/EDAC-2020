package Assignment6;
interface bank
{
    void display();
}

class customer implements bank
{
    String name;
    int amount;
    String des;
 customer(String name,int amount,String des)
            {
        this.name = name;
        this.amount = amount;
        this.des = des;
            }
    public void display()
    {
        System.out.println("Name = "+ name);
        System.out.println("Amount = "+ amount);
        System.out.println("Account No = "+ des);
    }
 }

class que
{
    public static void main(String args[])
    {
        customer  s = new customer("Ram",1200,"Abc157");
        s.display();
        
     
    }
}
