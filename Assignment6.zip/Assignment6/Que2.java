//package Assignment6;
class Employee
{
    String name;
    int age;
    int pn;
    String address;
    int salary;
    void Employee(String name,int age,int pn,String address,int salary)
    {
        this.name = name;
        this.age = age;
        this.pn = pn;
        this.address = address;
        this.salary = salary;
    }
   
    void details()
    {
        System.out.println("Name = " + name);
        System.out.println("Age = " + age);
        System.out.println("Phone Number " + pn);
        System.out.println("Address = " + address);
    }
     void printSalary()
    {
        System.out.println("Salary = " + salary);
    }
}

class Manager extends Employee
{
    
    void display(String specilization )
    {
       details();
       printSalary();
       System.out.println("Specilization = " + specilization);
    }
}

class Worker extends Employee
{
  
    void display(String department)
    {
       details();
       printSalary();
       System.out.println("Department " + department);
    }
}


class Inheritance3
{
    public static void main(String args[])
    {
        
        Manager e = new Manager();
        e.Employee("Ram",22,34344,"Mum",5000);
        e.display("Manager");
        
        System.out.println(" ");
        
        Manager m = new Manager();
        m.Employee("Sam",221,341,"Worker",25000);
        m.display("Worker");
    }
}