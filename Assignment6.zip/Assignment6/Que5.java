package Assignment6;
interface Company
{
    void salary();
    
}

class Employee()
{
    public void salary();
}

class Salary extends Employee implements Company
{
    String name;
    int salary;
    
    Salary(String name,int salary)
    {
        this.name = name;
        this.salary = salary;
    }
    public void salary()
    {
        System.out.println("Name= "+name);
        System.out.println("Salary= +"+salary);
    }
}
class Que5
{
    public static void main(String args[])
    {
        Salary s = new Salary()
    }
}