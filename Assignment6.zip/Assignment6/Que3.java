package Assignment6;
interface School
{
    public void details();
    
}
class Student implements School
{
    String name;
    int rollNo;
    int std;
    
    Student(String name,int rollNo,int std)
    {
        this.name = name;
        this.rollNo = rollNo;
        this.std = std;
    }
    public void details()
    {
        System.out.println("Name"+" "+name);
        System.out.println("RollNo"+" "+rollNo);
        System.out.println("Std"+" "+std);
    }
}
class Teacher implements School
{
    String name;
    String designation;
    int experience;
    
    Teacher(String name,String designation,int experience)
    {
        this.name = name;
        this.designation = designation;
        this.experience = experience;
        
    }
    public void details()
    {
        System.out.println("Name"+" "+name);
        System.out.println("Designation"+" "+designation);
        System.out.println("Experience"+" "+experience);
    }
}
class Que3
{
    public static void main(String args[])
    {
        Student s= new Student("xyz",1,4);
        s.details();
        System.out.println();
        Teacher t = new Teacher("pqr","Principle",10);
        t.details();
    }
}