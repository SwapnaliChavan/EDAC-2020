package assignment2;
class HollowFullPyramid
{
    public static void main(String args[])
  {  int i,j,k,sp=20,sp1=20;
    for (i = 0; i <= 5; i++) 
    { 
    	 for(k=1;k<=sp;k++)
    	    {
    		System.out.print(" ");
    	    }
    	   sp--;
           for (j = 1; j <= i; j++) 
            { 
    	        if( i == 1 || i == 5  || j == 1 || j == 5 )
    	        {
                System.out.print(" *"); 
                } 
    	        else
    	        {
                System.out.print(" ");  
                } 
    	    
            }
             //for(int n =1;n<=j;n++)
           {
               {
                  if( j == 1 )
    	        {
                System.out.print(" * "); 
                } 
                 if( j == 2 )
                {
                System.out.print(" *"); 
                } 
                if( j == 3 )
                {
                System.out.print("  *"); 
                } 
                if( j == 4 )
                {
                System.out.print("   *"); 
                } 
                if( j == 5 )
                {
                System.out.print("    *"); 
                } 
                if( j == 6 )
                {
                System.out.print(" *"); 
                } 
    	        else
    	        {
                System.out.print(" ");  
                } 
               }
               sp1++;
           }
                System.out.println();
         } 
               
    } 
 }

 