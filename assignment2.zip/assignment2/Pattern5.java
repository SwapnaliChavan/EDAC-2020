package assignment2;
public class Pattern5 
{
	public static void main(String[] args) 
	{
		for (int i = 10; i >= 1; i--) 
		{  
			for (int j = 1; j < i; j++) 
			{
				System.out.print("  ");
			}
			for (int j = i; j <= 9; j++)
			{
				System.out.print(j+" ");
			}         
			for (int n = 8; n>= i; n--)
			{
				System.out.print(n+" ");
			}         
                    	System.out.println();
		}
	}
}
	
	