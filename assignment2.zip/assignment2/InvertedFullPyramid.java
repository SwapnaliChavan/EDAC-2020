package assignment2;
class InvertedFullPyramid
{
	public static void main(String args[])
	{
	int space=20;
		for(int i=6;i >=1 ;i--)
		{
			for(int k=1;k<=space;k++)			
			{
				System.out.print(" ");
			}
			space++;
			for(int j=1; j<=i ;j++)
			{
				System.out.print("* ");
			}
			System.out.println( );
		}
				

	}
}
