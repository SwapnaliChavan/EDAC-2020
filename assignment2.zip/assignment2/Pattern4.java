package assignment2;
public class Pattern4 
{
	public static void main (String args[])
    
	  {
      int i,j,k,sp=20,a,b=1; 
      for(i=1;i<=9;i++)
         {
              for(k=1;k<=sp;k++)
              {
                  System.out.print("  ");
              }
              sp--;
              for(j=1;j<=i;j++)
              {
                   System.out.print(j+" ");
              }
              if(i>1)
              {
                for(a=b;a>=1;a--)
                {
                   System.out.print(a+" ");
                }
                b++;
              }
                   System.out.println("");
          }
   }
}
        
      