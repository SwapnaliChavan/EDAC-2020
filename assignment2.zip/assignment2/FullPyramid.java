package assignment2;
class FullPyramid
{
	public static void main(String args[])
	{
	int space=20;
		for(int i=1;i <=6 ;i++)
		{
			for(int k=1;k<=space;k++)			
			{
				System.out.print(" ");
			}
			space--;
			for(int j=1; j<=i ;j++)
			{
				System.out.print("* ");
			}
			System.out.println( );
		}
				

	}
}
