/*1)WAP to define a class Student with attributes rollno, name , 
	marks accept data for 2 objects and display them.*/
package Assignment4;
class Student
{
    int rollNo;
    String name;
    double marks;

void Student(int rn ,String n,double m)
{
    rollNo = rn;
    name = n;
    marks = m;
}

void display()
{
    System.out.println("RollNo= "+rollNo);
    System.out.println("Name= "+name);
    System.out.println("marks= "+marks); 
}
}
class Que1
{
    public static void main(String args[])
    {
          Student s1 = new Student();
          Student s2 = new Student();
          
          s1.Student(111,"Swapnali",90.00);
          s2.Student(112,"Samiksha",90.00);
          
          s1.display();
          System.out.println(); 
          s2.display();
    }
}
