/*3)WAP to define a class Bank accept customerid, name, balance write method  
	to perform deposit, checkbal, withdraw keep min balance 1000.*/

package Assignment4;
class Bank
{
    int customerid;
    String name;
    double balance;
    
    
//Method to initialize object  
void insert(int a,String n,float amt){  
customerid=a;  
name=n;  
balance=amt;  
}  
//deposit method  
void deposit(float amt)
{  
balance=balance+amt;  
System.out.println(amt+" deposited");  
}  
//withdraw method  
void withdraw(float amt)
{  
if(balance<amt)
{  
System.out.println("Insufficient Balance ");  
}
else
{  
balance=balance-amt;  
if(balance<1000)
{
    System.out.println("Minimum 1000 Balance Required ");  
}
else
{
System.out.println(amt+" withdrawn");  
}
}  
}  
//method to check the balance of the account  
void checkBalance()
{
    System.out.println("Balance is: "+balance);
  
}

//method to display the values of an object  
void display()
{
System.out.println(customerid+" "+name+" "+balance);
}  

}

//Creating a test class to deposit and withdraw amount  
class TestAccount
{  
public static void main(String[] args)
{  
Bank a1=new Bank();  
a1.insert(832345,"Anup",1000);  
a1.display();  
a1.checkBalance();  
a1.deposit(40000);  
a1.checkBalance();  
a1.withdraw(15000);  
a1.checkBalance();
a1.withdraw(25500);  

}
}   