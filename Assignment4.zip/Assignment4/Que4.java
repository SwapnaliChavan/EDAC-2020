/*4)WAP to define a class Employee with attributes id, name ,designation  accept data for 
	5 objects and display employee details whose designation is Manager.*/
package Assignment4;
class Employee
{
    int id;
    String name;
    String designation;
    
    void Employee(int i,String n,String d)
    {
        id=i;
        name=n;
        designation=d;
        check();
    }
    void display()
    {
        System.out.println("ID= "+id);
        System.out.println("Name= "+ name);
        System.out.println("Designation= "+designation);
    }
    
    void check()
    {
        if(designation == "Manager")
        {
            System.out.println("***** Employeer with Manager Designation ***** ");
            display();
            System.out.println();
        }
    }
    
}
class Que4
{
    public static void main(String args[])
    {
        Employee e1 = new Employee();
        Employee e2 = new Employee();
        Employee e3 = new Employee();
        Employee e4 = new Employee();
        Employee e5 = new Employee();
        
        e1.Employee(1,"Swapnali","CEO");
        e2.Employee(2,"Geeta","Manager");
        e3.Employee(3,"Ram","HR");
        e4.Employee(4,"Sham","Engineer");
        e5.Employee(5,"Seeta","Team Leader");
        
        System.out.println("***** Employeer Details *****");
        e1.display();
        System.out.println();
        e2.display();
        System.out.println();
        e3.display();
        System.out.println();
        e4.display();
        System.out.println();
        e5.display();
        
        /* e1.check();
         e2.check();
         e3.check();
         e4.check();
         e5.check();*/
        
    }
}