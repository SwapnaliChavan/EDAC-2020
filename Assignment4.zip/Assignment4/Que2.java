/*2)WAP to define a class Book with attributes id, name , 
	price accept data for 5 objects display book with highest price.*/

package Assignment4;
class Book
{
    int id;
    String name;
    double price;
    
    void Book(int i,String n,double p)
    {
        id = i;
        name = n;
        price = p;
        
    }
    void display()
    {
        System.out.println("id= "+id);
        System.out.println("Name= "+name);
        System.out.println("Price= "+price);
    }

        void min()
        {
            double min=price;
       
            //for(int i=0;i<price;i++)
       
            if(min>price)
            min=price;

            System.out.println(min);
   }
}
class Que2
{
    public static void main(String args[])
    {
 
        Book b1 = new Book();
        Book b2 = new Book();
        Book b3 = new Book();
        Book b4 = new Book();
        Book b5 = new Book();
        Book b6 = new Book();
        
        b1.Book(1,"Science",200.00);
        b2.Book(1,"Physics",201.00);
        b3.Book(1,"Chemistry",202.00);
        b4.Book(1,"Biology",203.00);
        b5.Book(1,"Maths",204.00);
        
        
        b1.display();
        System.out.println();
        b2.display();
        System.out.println();
        b3.display();
        System.out.println();
        b4.display();
        System.out.println();
        b5.display();
        b6.min();
        
    }
}
