/*
2.Create a class Circle that has two data members, 
one to store the radius and another to store area
and three methods first init() method to input radius from user,
second calculateArea() method to calculate area of circle
and third display() method to display values of radius and area. 
Create class CircleDemo ( main class) that creates the Circle object
and calls init(), calculateArea() and display() methods.
*/
import java.util.Scanner;
class Circle
{
    float radius;
    float area;
    
    void init(float radius)
    {
        this.radius = radius;
        
    }
    void calculateArea()
    {
        float pie = 3.14f;
        area = pie * radius*radius;
    }
    void display()
    {
        System.out.println("Radius= "+radius);
        System.out.println("Area= "+area);
    }
}
class CircleDemo
{
    public static void main(String args[])
    {
        float r;
        Scanner ss = new Scanner(System.in);
        System.out.println("Enter radius ");
        r=ss.nextFloat();
        
        Circle c1 = new Circle();
    
        c1.init(r);
        c1.calculateArea();
        c1.display();
    }
    
}

