/*
3.Create a class MathOperation that has four static methods. 
add() method that takes two integer numbers as parameter and returns the sum of the numbers.
subtract() method that takes two integer numbers as parameter and returns the difference of the numbers.
multiply() method that takes two integer numbers as parameter and returns the product. 
power() method that takes two integer numbers as parameter and returns the power of first number to second number. 
Create another class Demo (main class) that takes the two numbers from the user and 
calls all four methods of MathOperation class by providing entered numbers and 
prints the return values of every method.
*/
import java.util.Scanner;
class MathOperation
{
    
    static int addition(int a, int b)
    {
         int add = a+b;
         return add;
    }
    static int subtract(int a, int b)
    {
        int sum  = a-b;
         return sum;
    }
    static int multiply(int a, int b)
    {
        int mul  = a*b;
        return mul;
    }
    static double power(int a, int b)
    {
        double pow  = (Math.pow(a, b)); 
         return (int)pow;
    }
}
class Demo
{
    public static void main(String args[])
    {
        int num1 ,num2;
        Scanner ss = new Scanner(System.in);
        System.out.println("Enter number 1 is ");
        num1 = ss.nextInt();
        
        System.out.println("Enter number 2 is ");
        num2 = ss.nextInt();
        
        System.out.println();
        
        MathOperation s = new MathOperation();
        System.out.println("addition = "+s.addition(num1,num2));
        
        System.out.println();
        
        System.out.println("Subtraction = "+s.subtract(num1,num2));
        
        System.out.println();
        
        System.out.println("Multiplication = "+s.multiply(num1,num2));
        
        System.out.println();
        
        System.out.println("Power =" +s.power(num1,num2));

    }
}