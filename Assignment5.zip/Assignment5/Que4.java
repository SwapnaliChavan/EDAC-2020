/*
4.Create a class MathOperation containing overloaded methods ‘multiply’ to calculate multiplication of following arguments. 
a.two integers 
b.three floats 
c.all elements of array 
d.one double and one integer 

*/
class MathOperation1
{
    void multiply1(int a,int b)
    {
        int mul1 = a*b;
        System.out.println("Multiplication of two integer is = "+mul1);
    }
    void multiply2(float x,float y ,float z)  
    {
        float mul2 = x*y*z;
        System.out.println("Multiplication of three float is= "+mul2);
    }
     void multiply3(int arr[])
     {
        int a = 1;
        for(int i =0;i<arr.length;i++)
        {
            a = a* arr[i];
        }
         System.out.println("Multiplication of array elelments "+a);
    }
     
    void multiply4(double n , int m)
    {
        double mul4 = n*m;
        System.out.println("Multiplication of one double and one integer"+mul4);
    }
}
class Overload
{
    public static void main(String args[])
    {
        int arr[] = {1,2,3,4,5,6};
        MathOperation1 s = new MathOperation1();
        
        s.multiply1(2,2);
        
        s.multiply2(2.2f,2.2f,2.2f);
        
        s.multiply3(arr);
                
        s.multiply4(2.2,4);
        
    }
}